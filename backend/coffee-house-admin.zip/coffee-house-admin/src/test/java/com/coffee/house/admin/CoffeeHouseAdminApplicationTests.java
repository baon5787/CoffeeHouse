package com.coffee.house.admin;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CoffeeHouseAdminApplicationTests {

	@Test
	void contextLoads() {
	}

}
